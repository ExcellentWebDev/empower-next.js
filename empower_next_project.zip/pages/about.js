import Layout from '../components/Layout';

const About = () => (
    <Layout>
        <div className="container">
            
        </div>
        <style jsx>{`
        
        `}</style>
    </Layout>
);

export default About;